from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
import random
import string
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SECRET_KEY'] = 'your_secret_key_here'

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    position = db.Column(db.String(120), nullable=False)
    rating = db.Column(db.String(10), nullable=False)
    comment = db.Column(db.String(200), nullable=True)
    code_number = db.Column(db.String(10), nullable=False)
    verification_key = db.Column(db.String(10), nullable=False)
    work_experience = db.Column(db.String(20), nullable=False)

    def __repr__(self):
        return f'<User {self.email}>'

def generate_verification_key():
    return ''.join(random.choices(string.digits, k=10))

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        position = request.form['position']
        rating = request.form['rating']
        comment = request.form['comment']
        code_number = request.form['code_number']

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered', 'warning')
            return redirect(url_for('register'))

        verification_key = generate_verification_key()
        work_experience = calculate_work_experience(verification_key)

        new_user = User(first_name=first_name, last_name=last_name, email=email, password=password,
                        position=position, rating=rating, comment=comment, code_number=code_number,
                        verification_key=verification_key, work_experience=work_experience)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email, password=password).first()

        if user:
            session['user_id'] = user.id
            return redirect(url_for('loading'))
        else:
            flash('Invalid email or password', 'danger')
    return render_template('login.html')

@app.route('/loading')
def loading():
    return render_template('loading.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    user = User.query.get(user_id)
    return render_template('dashboard.html', user=user)

def calculate_work_experience(key):
    key_numbers = [int(d) for d in key if d != '0']
    result = key_numbers[0] - key_numbers[1] + key_numbers[2] - key_numbers[3] + key_numbers[4] - key_numbers[5] + key_numbers[6] - key_numbers[7] + key_numbers[8]
    if result < 0:
        result = -result
    return f'{result}/10 ({result * 10}%)'

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=8080, debug=True)
